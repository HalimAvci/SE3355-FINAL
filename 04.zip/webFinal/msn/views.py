from django.http.response import HttpResponse
from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request, "msn/index.html")

def news(request):
    return render(request, "msn/news.html")

