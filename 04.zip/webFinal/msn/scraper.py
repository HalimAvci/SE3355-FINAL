import requests
from bs4 import BeautifulSoup

url = "https://www.msn.com/tr-tr?AR=2"

safya = requests.get(url)

html_sayfa = BeautifulSoup(sayfa.content, "html.parser")

isim = html_sayfa.find("h3", class="info-pane-slide-title").getText()

print(isim)